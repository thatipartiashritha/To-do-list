PERMALIST <br/><br/>
Can only add and delete tasks for now. :'( <br/>
Also i hate the styling ╯︿╰<br/>

PostgreSQL query<br/>

CREATE TABLE tasks (<br/>
	id SERIAL PRIMARY KEY,<br/>
	task TEXT<br/>
); <br/><br/>